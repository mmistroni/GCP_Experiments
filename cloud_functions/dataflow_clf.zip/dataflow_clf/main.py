import requests     
from datetime import datetime


def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    request_json = request.get_json()
    job_str = "dataflow_clf_{}".format(datetime.now().strftime('%Y%m%d-%H%M'))
    return 'Hello World!-{}'.format(job_str)
