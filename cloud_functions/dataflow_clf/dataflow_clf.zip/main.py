import requests
import json
from datetime import datetime
from googleapiclient.discovery import build
from oauth2client.client import GoogleCredentials




def generate_api_client():
    print('Generating API CLIENT KEYS')
    credentials = GoogleCredentials.get_application_default()
    service = build('dataflow', 'v1b3', credentials=credentials)

    PROJECT = 'datascience-projects'
    BUCKET = 'mm_dataflow_bucket'
    TEMPLATE = 'dataflow_clf_template'
    GCSPATH="gs://{bucket}/templates/{template}".format(bucket=BUCKET, template=TEMPLATE)
    BODY = {
       "jobName": "clfshareloader_{}".format(datetime.now().strftime('%Y%m%d-%H%M')),
       "parameters": {},
       "environment": {
           "tempLocation": "gs://{bucket}/temp".format(bucket=BUCKET)
       }
    }


    request = service.projects().templates().launch(projectId=PROJECT, gcsPath=GCSPATH, body=BODY)
    response = request.execute()
    return str(response)

def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    request_json = request.get_json()

    response = generate_api_client()
    return response
